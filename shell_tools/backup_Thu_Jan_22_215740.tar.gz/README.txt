Default Skeleton
----------------

The Default Skeleton is an empty application template. 

